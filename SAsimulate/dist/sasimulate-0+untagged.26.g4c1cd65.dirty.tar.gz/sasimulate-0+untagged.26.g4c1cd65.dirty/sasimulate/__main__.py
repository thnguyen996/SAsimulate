from sasimulate import cli

cli.cli()
