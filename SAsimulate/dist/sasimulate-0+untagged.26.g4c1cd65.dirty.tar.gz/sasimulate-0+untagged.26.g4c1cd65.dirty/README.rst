===============================
sasimulate
===============================


.. image:: https://img.shields.io/travis/thnguyen996/sasimulate.svg
        :target: https://travis-ci.org/thnguyen996/sasimulate
.. image:: https://circleci.com/gh/thnguyen996/sasimulate.svg?style=svg
    :target: https://circleci.com/gh/thnguyen996/sasimulate
.. image:: https://codecov.io/gh/thnguyen996/sasimulate/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/thnguyen996/sasimulate


Simulate stuck-at-faults neural network 
